package ua.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

import ua.editor.CountryEditor;
import ua.entity.Country;
import ua.entity.Producer;
import ua.service.ProducerService;
import ua.service.CountryService;

import ua.editor.*;
import ua.entity.*;
import ua.service.*;

@Controller
@RequestMapping("/admin/category")
@SessionAttributes(names="category")
public class CategoryController {
	
	@Autowired
	private CategoryService categoryService;
	
	@RequestMapping
	public String show(Model model){
		model.addAttribute("categories", categoryService.findAll());
		return "admin-category";
	}

	@ModelAttribute("category")
	public Category getForm(){
		return new Category();
	}
	
	
	@RequestMapping("/delete/{id}")
	public String delete(@PathVariable int id){
		categoryService.delete(id);
		return "redirect:/admin/category";
	}
	
	@RequestMapping("/update/{id}")
	public String update(@PathVariable int id, Model model){
		model.addAttribute("category",categoryService.findOne(id));
		model.addAttribute("categories", categoryService.findAll());
		return "admin-category";
	}
	
	
	
	@RequestMapping(method=POST)
	public String save(@ModelAttribute("category") Category category, SessionStatus status){
	
		categoryService.save(category);
		status.setComplete();
		return "redirect:/admin/category";
	}
}