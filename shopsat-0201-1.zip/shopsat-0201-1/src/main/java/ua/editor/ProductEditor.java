package ua.editor;

import java.beans.PropertyEditorSupport;

import ua.entity.*;
import ua.service.*;

public class ProductEditor  extends PropertyEditorSupport{
	
	private final ProductService productService;

	public ProductEditor(ProductService productService) {
		super();
		this.productService = productService;
	}
	
	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		Product product = productService.findOne(Integer.valueOf(text));
		setValue(product);
	}

}
