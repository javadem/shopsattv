package ua.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ua.entity.*;

public interface MeasureRepository extends JpaRepository<Measure, Integer>{

}
