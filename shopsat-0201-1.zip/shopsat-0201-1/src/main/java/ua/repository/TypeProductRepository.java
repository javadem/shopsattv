package ua.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ua.entity.*;

public interface TypeProductRepository extends JpaRepository<TypeProduct, Integer>{

	@Query("SELECT i FROM TypeProduct i LEFT JOIN FETCH i.category ")
	List<TypeProduct> findAll();
	
	@Query("SELECT DISTINCT i FROM TypeProduct i LEFT JOIN FETCH i.category WHERE "
			+ "i.id=:id"
			)
	TypeProduct findOne(@Param("id")int id);
}
