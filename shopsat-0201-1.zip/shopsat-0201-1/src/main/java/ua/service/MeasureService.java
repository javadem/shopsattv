package ua.service;

import java.util.List;

import ua.entity.*;

public interface MeasureService {
	
	Measure findOne(int id);
	
	List<Measure> findAll();
	
	void save(Measure measure);
	
	void delete(int id);
}
