package ua.service.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ua.entity.*;
import ua.repository.*;
import ua.service.*;

@Service
public class MeasureServiceImpl implements MeasureService{


	@Autowired
	private MeasureRepository  repository;

	@Override
	@Transactional(readOnly=true)
	public Measure findOne(int id) {
		// TODO Auto-generated method stub
		return repository.findOne(id);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Measure> findAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public void save(Measure measure) {
		// TODO Auto-generated method stub
		repository.save(measure);
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		repository.delete(id);
	}

	
}
