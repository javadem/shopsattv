package ua.service.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ua.entity.*;
import ua.repository.*;
import ua.service.*;

@Service
public class ProductServiceImpl implements ProductService{
	

	@Autowired
	private ProductRepository  productRepository;
	
	@Autowired
	private ModelRepository  modelRepository;
	
	@Autowired
	private MeasureRepository  measureRepository;

	@Override
	@Transactional(readOnly=true)
	public Product findOne(int id) {
		// TODO Auto-generated method stub
		return productRepository.findOne(id);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public void save(Product product) {
		// TODO Auto-generated method stub
		productRepository.save(product);
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		productRepository.delete(id);
	}


	
}
