package ua.service.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ua.entity.*;
import ua.repository.*;
import ua.service.*;

@Service
public class TypeProductServiceImpl implements TypeProductService{

	

	@Autowired
	private TypeProductRepository  repository;
	
//	@Autowired
//	private CategoryRepository  categoryRepository;

	@Override
	@Transactional(readOnly=true)
	public TypeProduct findOne(int id) {
		// TODO Auto-generated method stub
		return repository.findOne(id);
	}

	@Override
	@Transactional(readOnly=true)
	public List<TypeProduct> findAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public void save(TypeProduct typeProduct) {
		// TODO Auto-generated method stub
		repository.save(typeProduct);
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		repository.delete(id);
	}

	
	
}
