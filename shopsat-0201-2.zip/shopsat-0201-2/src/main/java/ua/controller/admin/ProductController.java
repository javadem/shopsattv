package ua.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import static org.springframework.web.bind.annotation.RequestMethod.POST;



import ua.editor.*;
import ua.entity.*;
import ua.service.*;

@Controller
@RequestMapping("/admin/product")
@SessionAttributes(names="product")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private ModelService modelService;
	
	@Autowired
	private MeasureService measureService;
	
	
	
	
	@InitBinder("product")
	protected void initBinder(WebDataBinder binder){
		binder.registerCustomEditor(ua.entity.Model.class, new ModelEditor(modelService));
		binder.registerCustomEditor(Measure.class, new MeasureEditor(measureService));
		
	}
	
	@ModelAttribute("product")
	public Product getForm(){
		return new Product();
	}
	
	@RequestMapping
	public String show(Model model){
		model.addAttribute("products", productService.findAll());
		model.addAttribute("models", modelService.findAll());
		model.addAttribute("measures", measureService.findAll());
		return "admin-product";
	}
	
	@RequestMapping("/delete/{id}")
	public String delete(@PathVariable int id){
		productService.delete(id);
		return "redirect:/admin/product";
	}
	
	@RequestMapping("/update/{id}")
	public String update(@PathVariable int id, Model model){
		model.addAttribute("product", productService.findOne(id));
		model.addAttribute("products", productService.findAll());
		model.addAttribute("model", modelService.findOne(id));
		model.addAttribute("models", modelService.findAll());
		model.addAttribute("measure", measureService.findOne(id));
		model.addAttribute("measures", measureService.findAll());
		return "admin-product";
	}

	@RequestMapping(method=POST)
	public String save(@ModelAttribute("product") Product product, SessionStatus sessionStatus){
		productService.save(product);
		sessionStatus.setComplete();
		return "redirect:/admin/product";
}

}
