package ua.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ua.entity.Product;


public interface ProductRepository extends JpaRepository<Product, Integer>{

	@Query("SELECT i FROM Product i "
			+ "LEFT JOIN FETCH i.model "
			+ "LEFT JOIN FETCH i.priceMeasure "
			+ "LEFT JOIN FETCH i.productMeasure "
			)
	List<Product> findAll();
	
	@Query("SELECT DISTINCT i FROM Product i "
			+ "LEFT JOIN FETCH i.model "
			+ "LEFT JOIN FETCH i.priceMeasure "
			+ "LEFT JOIN FETCH i.productMeasure "
			+ " WHERE i.id=:id"
			)
	Product findOne(@Param("id")int id);
	
	Product findByName(String name);
	
}
