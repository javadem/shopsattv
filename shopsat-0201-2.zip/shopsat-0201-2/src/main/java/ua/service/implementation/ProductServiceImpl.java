package ua.service.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ua.dto.form.ProductForm;
import ua.entity.*;
import ua.repository.*;
import ua.service.*;

@Service
public class ProductServiceImpl implements ProductService{
	

	@Autowired
	private ProductRepository  productRepository;
	
	@Autowired
	private ModelRepository  modelRepository;
	
	@Autowired
	private MeasureRepository  measureRepository;

	@Override
	@Transactional(readOnly=true)
	public Product findOne(int id) {
		// TODO Auto-generated method stub
		return productRepository.findOne(id);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public void save(Product product) {
		// TODO Auto-generated method stub
		productRepository.save(product);
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		productRepository.delete(id);
	}

	@Override
	public Product findOne(String name) {
		return productRepository.findByName(name);
	}

	@Override
	public void save(ProductForm product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Product> findByModelId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> findByMeasureId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public ProductRepository getProductRepository() {
		return productRepository;
	}

	public void setProductRepository(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	public ModelRepository getModelRepository() {
		return modelRepository;
	}

	public void setModelRepository(ModelRepository modelRepository) {
		this.modelRepository = modelRepository;
	}

	public MeasureRepository getMeasureRepository() {
		return measureRepository;
	}

	public void setMeasureRepository(MeasureRepository measureRepository) {
		this.measureRepository = measureRepository;
	}
	
	
}
