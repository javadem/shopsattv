package ua.service;

import java.util.List;

import ua.dto.form.ProductForm;
import ua.entity.*;

public interface ProductService {

	Product findOne(int id);
	
	List<Product> findAll();
	
	void save(Product product);
	
	void delete(int id);
	
	Product findOne(String name);
	
	void save(ProductForm product);
	
	List<Product> findByModelId(int id);
	
	List<Product> findByMeasureId(int id);
}
