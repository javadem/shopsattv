package ua.validator;


import java.util.regex.Pattern;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import ua.entity.Product;
import ua.service.ProductService;

import ua.dto.form.ProductForm;

public class ProductValidator  implements Validator{

	private final ProductService productServiceProductValidator;

	private final static Pattern PATTERN = Pattern.compile("^([0-9]{1,18}\\.[0-9]{0,2})|([0-9]{1,18}\\,[0-9]{0,2})$");

	
	public ProductValidator(ProductService productServiceProductValidator) {
		super();
		this.productServiceProductValidator = productServiceProductValidator;
	}

	public ProductService getProductServiceProductValidator() {
		return productServiceProductValidator;
	}



	@Override
	public boolean supports(Class<?> clazz) {
		return ProductForm.class.equals(clazz);
	}

//	@Override
//	public void validate(Object target, Errors errors) {
//		Product product = (Product)target;
//		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "", "Can`t be empty");
//		if(productServiceProductValidator.findOne(product.getNameProduct())!=null){
//			errors.rejectValue("name", "", "Already exist");
//		}
//	}

	@Override
	public void validate(Object target, Errors errors) {
		Product product = (Product)target;
		ProductForm productForm = (ProductForm) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "", "Can`t be empty");
		if(productServiceProductValidator.findOne(product.getNameProduct())!=null){
			errors.rejectValue("name", "", "Already exist");
		}
		if(!PATTERN.matcher(productForm.getPrice()).matches()){
			errors.rejectValue("price", "", "Wrong format, only 2 digits after separator");
		}
		
	}
	
	
}
