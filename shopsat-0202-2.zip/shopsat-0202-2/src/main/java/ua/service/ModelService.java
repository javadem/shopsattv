package ua.service;

import java.util.List;

import ua.entity.*;

public interface ModelService {

	ua.entity.Model findOne(int id);
	
	List<Model> findAll();
	
	void save( ua.entity.Model model);
	
	void delete(int id);
	
	Model findOne(String name);
	
	List<Model> findByTypeProductId(int id);
	
	List<Model> findByProducerId(int id);
	
}
