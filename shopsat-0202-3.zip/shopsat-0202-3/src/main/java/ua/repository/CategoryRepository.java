package ua.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import ua.entity.Category;

//@Component
public interface CategoryRepository extends JpaRepository<Category,  Integer>{

	@Query("SELECT DISTINCT c FROM Category c  WHERE c.id=:id")
	Category findOne(@Param("id")int id);

//	Category findByName(String name);
	
	
}
