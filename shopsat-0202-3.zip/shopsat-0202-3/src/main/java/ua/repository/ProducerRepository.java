package ua.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ua.entity.*;

public interface ProducerRepository extends JpaRepository<Producer, Integer>{

	@Query("SELECT i FROM Producer i LEFT JOIN FETCH i.country ")
	List<Producer> findAll();
	
	@Query("SELECT DISTINCT c FROM Producer c LEFT JOIN FETCH c.country WHERE "
			+ "c.id=:id"
			)
	Producer findOne(@Param("id")int id);
	
//	Producer findByName(String name);
	
}
