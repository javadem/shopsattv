package ua.service.implementation;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ua.entity.Category;
import ua.repository.CategoryRepository;
import ua.service.CategoryService;

@Service
public class CategoryServiceImpl  implements CategoryService{

	@Autowired
	private CategoryRepository categoryRepositoryServiceImpl;
	
	
	
	
	@Override
	@Transactional(readOnly=true)
	public Category findOne(int id) {
		// TODO Auto-generated method stub
		return categoryRepositoryServiceImpl.findOne(id);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Category> findAll() {
		// TODO Auto-generated method stub
		return categoryRepositoryServiceImpl.findAll();
	}

	@Override
	public void save(Category category) {
		categoryRepositoryServiceImpl.save(category);
		
	}

	@Override
	public void delete(int id) {
		categoryRepositoryServiceImpl.delete(id);
		
	}
	
	
	
	@Override
	public Category findOne(String nameCategory) {
		// TODO Auto-generated method stub
		return null;
	}

	public CategoryRepository getCategoryRepository() {
		return categoryRepositoryServiceImpl;
	}

	public CategoryRepository getCategoryRepositoryServiceImpl() {
		return categoryRepositoryServiceImpl;
	}

	public void setCategoryRepositoryServiceImpl(CategoryRepository categoryRepositoryServiceImpl) {
		this.categoryRepositoryServiceImpl = categoryRepositoryServiceImpl;
	}

	
	
	
}
