package ua.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

import javax.validation.Valid;

import ua.editor.*;
import ua.entity.*;
import ua.service.*;

import ua.editor.ModelEditor;
//import src.main.java.ua.entity.Model;
import ua.service.ModelService;
import ua.validator.ModelValidator;

@Controller
@RequestMapping("/admin/model")
@SessionAttributes(names="model")
public class ModelController {

	@Autowired
	private ModelService modelService;
	
	@Autowired
	private TypeProductService typeProductService;
	
	@Autowired
	private ProducerService producerService;
	
	@InitBinder("model")
	protected void initBinder(WebDataBinder binder){
		binder.registerCustomEditor(TypeProduct.class, new TypeProductEditor(typeProductService));
		binder.registerCustomEditor(Producer.class, new ProducerEditor(producerService));
		binder.setValidator(new ModelValidator(modelService));
	}
	
	@ModelAttribute("model")
	public ua.entity.Model getForm(){
		return new ua.entity.Model();
	}
	
	@RequestMapping
	public String show(org.springframework.ui.Model modelSpring){
		modelSpring.addAttribute("models", modelService.findAll());
		modelSpring.addAttribute("producers", producerService.findAll());
		modelSpring.addAttribute("typeProducts", typeProductService.findAll());
		return "admin-model";
	}
	
	@RequestMapping("/delete/{id}")
	public String delete(@PathVariable int id){
		modelService.delete(id);
		return "redirect:/admin/model";
	}
	
	@RequestMapping("/update/{id}")
	public String update(@PathVariable int id, Model model){
		model.addAttribute("model", modelService.findOne(id));
		model.addAttribute("models", modelService.findAll());
		model.addAttribute("typeProduct", typeProductService.findOne(id));
		model.addAttribute("typeProducts", typeProductService.findAll());
		model.addAttribute("producer", producerService.findOne(id));
		model.addAttribute("producers", producerService.findAll());
		return "admin-model";
	}
	
//	@InitBinder("model")
//	protected void initBinder(WebDataBinder binder) {
//		binder.setValidator(new ModelValidator(modelService));
//	}
	
	@RequestMapping(method=POST)
	public String save(@ModelAttribute("model") @Valid ua.entity.Model form, BindingResult br, SessionStatus status, Model model){
		if(br.hasErrors()){
			model.addAttribute("models", modelService.findAll());
			return "admin-model";
		}
		modelService.save(form);
		status.setComplete();
		return "redirect:/admin/model";
	}

	
//	@RequestMapping(method=POST)
//	public String save(@ModelAttribute("model") ua.entity.Model model, SessionStatus sessionStatus){
//		modelService.save(model);
//		sessionStatus.setComplete();
//		return "redirect:/admin/model";
//	}
	
	
}
