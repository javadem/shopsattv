package ua.dto.form;


import ua.entity.Measure;
import ua.entity.Model;

public class ProductForm {
	
	
	private Model model;
	
	private String nameProduct;

	private String description;
	
	private String price ;
	
	private Measure priceMeasure;
	
	private Measure productMeasure;
	
	
	

	public ProductForm() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public ProductForm(Model model, String nameProduct, String description, String price, Measure priceMeasure,
			Measure productMeasure) {
		super();
		this.model = model;
		this.nameProduct = nameProduct;
		this.description = description;
		this.price = price;
		this.priceMeasure = priceMeasure;
		this.productMeasure = productMeasure;
	}



	public Model getModel() {
		return model;
	}

	public void setModel(Model model) {
		this.model = model;
	}

	public String getNameProduct() {
		return nameProduct;
	}

	public void setNameProduct(String nameProduct) {
		this.nameProduct = nameProduct;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public Measure getPriceMeasure() {
		return priceMeasure;
	}

	public void setPriceMeasure(Measure priceMeasure) {
		this.priceMeasure = priceMeasure;
	}

	public Measure getProductMeasure() {
		return productMeasure;
	}

	public void setProductMeasure(Measure productMeasure) {
		this.productMeasure = productMeasure;
	}

	
	
	

}
