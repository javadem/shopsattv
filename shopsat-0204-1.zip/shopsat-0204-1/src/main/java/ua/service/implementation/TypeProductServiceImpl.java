package ua.service.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ua.entity.*;
import ua.repository.*;
import ua.service.*;

@Service
public class TypeProductServiceImpl implements TypeProductService{

	

	@Autowired
	private TypeProductRepository  typeProductRepository;
	
	@Autowired
	private CategoryRepository  categoryRepositoryTypeProductServiceImpl;

	@Override
	@Transactional(readOnly=true)
	public TypeProduct findOne(int id) {
		// TODO Auto-generated method stub
		return typeProductRepository.findOne(id);
	}

	@Override
	@Transactional(readOnly=true)
	public List<TypeProduct> findAll() {
		// TODO Auto-generated method stub
		return typeProductRepository.findAll();
	}

	@Override
	public void save(TypeProduct typeProduct) {
		// TODO Auto-generated method stub
		typeProductRepository.save(typeProduct);
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		typeProductRepository.delete(id);
	}
	
	

//	@Override
//	public TypeProduct findOne(String name) {
//		return typeProductRepository.findByName(name);
//	}

	@Override
	public TypeProduct findOne(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TypeProduct> findByCategoryId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	

	public TypeProductRepository getTypeProductRepository() {
		return typeProductRepository;
	}

	public void setTypeProductRepository(TypeProductRepository typeProductRepository) {
		this.typeProductRepository = typeProductRepository;
	}

	public CategoryRepository getCategoryRepositoryTypeProductServiceImpl() {
		return categoryRepositoryTypeProductServiceImpl;
	}

	public void setCategoryRepositoryTypeProductServiceImpl(CategoryRepository categoryRepositoryTypeProductServiceImpl) {
		this.categoryRepositoryTypeProductServiceImpl = categoryRepositoryTypeProductServiceImpl;
	}
	
	
	
}
