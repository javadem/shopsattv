package ua.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ua.entity.*;

public interface MeasureRepository extends JpaRepository<Measure, Integer>{
	
	@Query("SELECT DISTINCT c FROM Measure c  WHERE c.id=:id")
	Measure findOne(@Param("id")int id);
	
	@Query("SELECT i FROM Measure i ")
	List<Measure> findAll();
	
	@Query("SELECT DISTINCT c FROM Measure c  WHERE c.nameMeasure=:name")
	Measure findByName(@Param("name")String name);

}
