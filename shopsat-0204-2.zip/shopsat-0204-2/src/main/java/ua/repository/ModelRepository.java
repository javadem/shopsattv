package ua.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ua.entity.*;

public interface ModelRepository extends JpaRepository<Model, Integer>{

	@Query("SELECT i FROM Model i LEFT JOIN FETCH i.typeProduct LEFT JOIN FETCH i.producer")
	List<Model> findAll();
	
	@Query("SELECT DISTINCT i FROM Model i LEFT JOIN FETCH i.typeProduct LEFT JOIN FETCH i.producer WHERE "
			+ "i.id=:id"
			)
	Model findOne(@Param("id")int id);
	
	@Query("SELECT DISTINCT c FROM Model c  WHERE c.nameModel=:name")
	Model findByName(@Param("name")String name);
	
}
