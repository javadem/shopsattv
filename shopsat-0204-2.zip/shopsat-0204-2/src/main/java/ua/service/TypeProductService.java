package ua.service;

import java.util.List;

import ua.entity.Producer;
import ua.entity.TypeProduct;

public interface TypeProductService {

	TypeProduct findOne(int id);
	
	List<TypeProduct> findAll();
	
	void save(TypeProduct typeProduct);
	
	void delete(int id);
	
	TypeProduct findOne(String name);
	
	List<TypeProduct> findByCategoryId(int id);
}
