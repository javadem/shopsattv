package ua.controller.admin;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import static org.springframework.web.bind.annotation.RequestMethod.POST;
import javax.validation.Valid;
import org.springframework.validation.BindingResult;

import java.util.List;

import ua.editor.CategoryEditor;
import ua.editor.ModelEditor;
import ua.entity.Category;
import ua.entity.TypeProduct;
import ua.service.TypeProductService;
import ua.validator.TypeProductValidator;

import ua.service.CategoryService;
import ua.service.ModelService;


@Controller
@RequestMapping("/admin/typeProduct")
@SessionAttributes(names="typeProduct")
public class TypeProductController {
	
	

	@Autowired
	private TypeProductService typeProductService;
	
	@Autowired
	private CategoryService categoryService;
	
//	@Autowired
//	private ModelService modelService;
	

	@InitBinder("typeProduct")
	protected void initBinder(WebDataBinder binder){
	binder.registerCustomEditor(Category.class, new CategoryEditor(categoryService));
//	binder.registerCustomEditor(ua.entity.Model.class, new ModelEditor(modelService));
	binder.setValidator(new TypeProductValidator(typeProductService));
	}
	
	@ModelAttribute("typeProduct")
	public TypeProduct getForm(){
		return new TypeProduct();
	}
	
	@RequestMapping
	public String show(Model model){
		model.addAttribute("typeProducts", typeProductService.findAll());
		model.addAttribute("categories", categoryService.findAll());
//		model.addAttribute("models", modelService.findAll());
//		model.addAttribute("typeProduct", typeProductService.findOne(id));
//		model.addAttribute("category", categoryService.findOne(id));
		return "admin-typeProduct";
	}
	
	@RequestMapping("/delete/{id}")
	public String delete(@PathVariable int id){
		typeProductService.delete(id);
		return "redirect:/admin/typeProduct";
	}
	
	@RequestMapping("/update/{id}")
	public String update(@PathVariable int id, Model model){
		model.addAttribute("typeProduct", typeProductService.findOne(id));
		model.addAttribute("typeProducts", typeProductService.findAll());
		model.addAttribute("category", categoryService.findOne(id));
		model.addAttribute("categories", categoryService.findAll());
		return "admin-typeProduct";
	}
	

	@RequestMapping(method=POST)
	public String save(@ModelAttribute("typeProduct") @Valid TypeProduct form, BindingResult br, SessionStatus status, Model model){
		if(br.hasErrors()){
			model.addAttribute("typeProducts", typeProductService.findAll());
			model.addAttribute("categories", categoryService.findAll());
			return "admin-typeProduct";
		}
		typeProductService.save(form);
		status.setComplete();
		return "redirect:/admin/typeProduct";
	}


}
