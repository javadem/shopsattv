package ua.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ua.entity.*;

public interface CountryRepository extends JpaRepository<Country, Integer>{

	@Query("SELECT DISTINCT c FROM Country c  WHERE c.id=:id")
	Country findOne(@Param("id")int id);
	
	@Query("SELECT DISTINCT c FROM Country c  WHERE c.nameCountry=:name")
	Country findByName(@Param("name")String name);

}
