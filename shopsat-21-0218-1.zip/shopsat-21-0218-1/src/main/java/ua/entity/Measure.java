package ua.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Index;

@Entity
@Table(name="measure", indexes=@Index(columnList = "_name"))
public class Measure extends AbstractClass{
	
	@Column(name="_name")
	private String nameMeasure;
	
	@OneToMany(mappedBy="measure")
	private List<Product> products = new ArrayList<>();

	public Measure() {
		
	}


	public Measure(String nameMeasure) {
		super();
		this.nameMeasure = nameMeasure;
	}


	public String getNameMeasure() {
		return nameMeasure;
	}


	public void setNameMeasure(String nameMeasure) {
		this.nameMeasure = nameMeasure;
	}


	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}


	
}
