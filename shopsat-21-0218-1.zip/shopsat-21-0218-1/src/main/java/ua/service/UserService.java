package ua.service;

import ua.entity.User;

public interface UserService {

	void save(User user);
}
