package ua.entity;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="country", indexes=@Index(columnList = "_name"))
public class Country  extends AbstractClass{

	@Column(name="_name")
	private String nameCountry;
	
	@OneToMany(mappedBy="country")
	private List<Producer> producers = new ArrayList<>();
	

	public Country() {
		
	}


	public Country(String nameCountry) {
		super();
		this.nameCountry = nameCountry;
	}

	

	public String getNameCountry() {
		return nameCountry;
	}

	public void setNameCountry(String nameCountry) {
		this.nameCountry = nameCountry;
	}

	public List<Producer> getProducers() {
		return producers;
	}



	public void setProducers(List<Producer> producers) {
		this.producers = producers;
	}

	
}
