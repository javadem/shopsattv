package ua.entity;

import java.math.BigDecimal;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import javax.persistence.Table;

@Entity
@Table(name="product", indexes=@Index(columnList = "_name, _description, _price") )
public class Product  extends AbstractClass{
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "id_model")
	private Model model;
	
	@Column(name="_name")
	private String nameProduct;

	@Column(name="_description")
	private String description;
	
	@Column(name="_price")
	private BigDecimal price ;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "id_price_measure")
	private Measure priceMeasure;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "id_product_measure")
	private Measure productMeasure;

	
	
	public Product() {
	
	}


	public Product(Model model, String nameProduct, String description, BigDecimal price, Measure priceMeasure,
			Measure productMeasure) {
		super();
		this.model = model;
		this.nameProduct = nameProduct;
		this.description = description;
		this.price = price;
		this.priceMeasure = priceMeasure;
		this.productMeasure = productMeasure;
	}


	public Model getModel() {
		return model;
	}
	public void setModel(Model model) {
		this.model = model;
	}
	
	
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public Measure getPriceMeasure() {
		return priceMeasure;
	}
	public void setPriceMeasure(Measure priceMeasure) {
		this.priceMeasure = priceMeasure;
	}
	public Measure getProductMeasure() {
		return productMeasure;
	}
	public void setProductMeasure(Measure productMeasure) {
		this.productMeasure = productMeasure;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}





	public String getNameProduct() {
		return nameProduct;
	}





	public void setNameProduct(String nameProduct) {
		this.nameProduct = nameProduct;
	}


	
}
