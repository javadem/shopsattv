package ua.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import ua.dto.form.ProductForm;
import ua.dto.filter.BasicFilter;
import ua.dto.filter.ProductFilter;
import ua.entity.Product;

public interface ProductService {

	Product findOne(int id);
	
	List<Product> findAll();
	
	void save(Product product);
	
	void update(Product product);
	
	void delete(int id);
	
	Product findOne(String name);
	
	void save(ProductForm productForm);
	
	void update(ProductForm productForm);
	
	void update(int id);
	
	List<Product> findByModelId(int id);
	
	List<Product> findByMeasureId(int id);

//	void getForm(int id);
	
//	Product getForm(int id);
	
	Product getForm();
	
//	Page<Product> findAll(Pageable pageable);

//	Page<Product> findAll(BasicFilter filter, Pageable pageable);
	
	Page<Product> findAll(ProductFilter filter, Pageable pageable);
}
