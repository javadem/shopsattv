package ua.service.specification;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;

import org.springframework.data.jpa.domain.Specification;

import ua.dto.filter.BasicFilter;
import ua.dto.filter.ProductFilter;
import ua.entity.Product;
import ua.entity.Measure;
import ua.entity.Model;

public class ProductSpecification   implements Specification<Product>{
	
	private final ProductFilter filter;
	
	private final List<Predicate> predicates = new ArrayList<>();
	
	public ProductSpecification(ProductFilter filter) {
		this.filter = filter;
	}

	private void filterByModel(Root<Product> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
		if(!filter.getModelIds().isEmpty()){
			predicates.add(root.get("model").in(filter.getModelIds()));
		}
	}
	
	private void filterByPrice(Root<Product> root, CriteriaQuery<?> query, CriteriaBuilder cb){
		if(filter.getMax()!=null&&filter.getMin()!=null){
			predicates.add(cb.between(root.get("price"), filter.getMin(), filter.getMax()));
		}else if(filter.getMax()!=null){
			predicates.add(cb.lessThanOrEqualTo(root.get("price"), filter.getMax()));
		}else if(filter.getMin()!=null){
			predicates.add(cb.greaterThanOrEqualTo(root.get("price"), filter.getMin()));
		}
	}

	private void filterBySearch(Root<Product> root, CriteriaQuery<?> query, CriteriaBuilder cb){
		if(!filter.getSearch().isEmpty()){
			predicates.add(cb.like(root.get("nameProduct"), filter.getSearch()+"%"));
		}
	}
	
	private void filterByPriceMeasure(Root<Product> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
		if(!filter.getPriceMeasureIds().isEmpty()){
			predicates.add(root.get("priceMeasure").in(filter.getPriceMeasureIds()));
		}
	}
	
	private void filterByProductMeasure(Root<Product> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
		if(!filter.getProductMeasureIds().isEmpty()){
			predicates.add(root.get("productMeasure").in(filter.getProductMeasureIds()));
		}
	}
	
	private void fetch(Root<Product> root, CriteriaQuery<?> query){
		if(query.getResultType()!=Long.class){
			root.fetch("model", JoinType.LEFT);
			root.fetch("priceMeasure", JoinType.LEFT);
			root.fetch("productMeasure", JoinType.LEFT);
		}
	}
	
	@Override
	public Predicate toPredicate(Root<Product> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
		
		fetch(root, query);
		query.distinct(true);
		filterBySearch(root, query, cb);
		filterByPrice(root, query, cb);
		filterByModel(root, query, cb);
		filterByPriceMeasure(root, query, cb);
		filterByProductMeasure(root, query, cb);

		if(predicates.isEmpty())return null;
		Predicate[] array = new Predicate[predicates.size()];
		predicates.toArray(array);
		return cb.and(array);

//		if(filter.getSearch().isEmpty()) return null;
//		return cb.like(root.get("name"), filter.getSearch()+"%");
	
	}
	

}
