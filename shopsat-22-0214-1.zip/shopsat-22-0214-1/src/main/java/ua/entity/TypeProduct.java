package ua.entity;

import java.util.ArrayList;
import java.util.List;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Index;

@Entity
@Table(name="type_product", indexes=@Index(columnList = "_name"))
public class TypeProduct  extends AbstractClass{
	
//	@ManyToOne(fetch=FetchType.LAZY, cascade={CascadeType.PERSIST, CascadeType.MERGE})
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "id_category")
	private Category category;
	
	@Column(name="_name")
	private String nameTypeProduct;
	
	
	@OneToMany(mappedBy="typeProduct")
	private List<Model> models = new ArrayList<>();
	
	
	public TypeProduct() {
		
	}
	

	public TypeProduct(Category category, String nameTypeProduct) {
		super();
		this.category = category;
		this.nameTypeProduct = nameTypeProduct;
	}


	public String getNameTypeProduct() {
		return nameTypeProduct;
	}


	public void setNameTypeProduct(String nameTypeProduct) {
		this.nameTypeProduct = nameTypeProduct;
	}


	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}

	public List<Model> getModels() {
		return models;
	}


	public void setModels(List<Model> models) {
		this.models = models;
	}


	
}
