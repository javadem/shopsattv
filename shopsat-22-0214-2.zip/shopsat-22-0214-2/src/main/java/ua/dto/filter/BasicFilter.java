package ua.dto.filter;

public class BasicFilter {


	private String search = "";

	public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}
	
}
