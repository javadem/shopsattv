package ua.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import ua.dto.form.ProductForm;
import ua.entity.Product;


public interface ProductRepository extends JpaRepository<Product, Integer>, JpaSpecificationExecutor<Product>{

	@Query("SELECT i FROM Product i "
			+ "LEFT JOIN FETCH i.model "
			+ "LEFT JOIN FETCH i.measure "

			)
	List<Product> findAll();
	
//	@Query("SELECT DISTINCT i FROM Product i "
//			+ "LEFT JOIN FETCH i.model "
//			+ "LEFT JOIN FETCH i.measure "

//			+ " WHERE i.id=:id"
//			)
//	Product findOne(@Param("id")int id);
	
	@Query("SELECT DISTINCT i FROM Product i "
			+ "LEFT JOIN FETCH i.model "
			+ "LEFT JOIN FETCH i.measure "

			+ " WHERE i.id=:id"
			)
	ProductForm findOne(@Param("id")int id);
	
	@Query("SELECT DISTINCT c FROM Product c  WHERE c.nameProduct=:name")
	Product findByName(@Param("name")String name);
	

	
	@Query(value="SELECT i FROM Product i "
			+ "LEFT JOIN FETCH i.model "
			+ "LEFT JOIN FETCH i.measure "
			, countQuery="SELECT count(i.id) FROM Product i"
			)
	Page<Product> findAll(Pageable pageable);
	
}
