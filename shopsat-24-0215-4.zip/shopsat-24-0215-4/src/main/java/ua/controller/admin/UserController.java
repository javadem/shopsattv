package ua.controller.admin;

import static org.springframework.web.bind.annotation.RequestMethod.POST;
import static ua.service.utils.ParamBuilder.getParams;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import ua.dto.filter.BasicFilter;
import ua.entity.User;
import ua.service.UserService;
import ua.validator.UserValidator;


@Controller
@RequestMapping("/admin/user")
@SessionAttributes(names="user")
public class UserController {

	

		@Autowired
		private UserService userService;
		

		
		@ModelAttribute("user")
		public User getForm(){
			return new User();
		}
		
		@ModelAttribute("filter")
		public BasicFilter getFilter(){
			return new BasicFilter();
		}
		
		@InitBinder("user")
		protected void initBinder(WebDataBinder binder) {
			binder.setValidator(new UserValidator(userService));
		}
		
		@RequestMapping
		public String show(SessionStatus status, Model model, @ModelAttribute("filter") BasicFilter filter, @PageableDefault Pageable pageable){
//			model.addAttribute("users", userService.findAll());
			model.addAttribute("page", userService.findAll( filter, pageable));
			return "admin-user";
		}
		
		
//		@RequestMapping("/delete/{id}")
//		public String delete(@PathVariable int id, @ModelAttribute("filter") BasicFilter filter, @PageableDefault Pageable pageable){
//			userService.delete(id);
//			return "redirect:/admin/user"+getParams(pageable, filter);
//		}
//		
//		@RequestMapping("/update/{id}")
//		public String update(@PathVariable int id, Model model, @ModelAttribute("filter") BasicFilter filter, @PageableDefault Pageable pageable){
//			model.addAttribute("user", userService.findOne(id));
//			model.addAttribute("page", userService.findAll( filter, pageable));
//			return "admin-user";
//		}
		
		
		
		@RequestMapping(method=POST)
		public String save(@ModelAttribute("user") @Valid User user, BindingResult br, SessionStatus status, Model model, @ModelAttribute("filter") BasicFilter filter, @PageableDefault Pageable pageable){
			if(br.hasErrors()){
//				model.addAttribute("users", userService.findAll());
				model.addAttribute("page", userService.findAll( filter, pageable));
				return "admin-user";
			}
			userService.save(user);
			status.setComplete();
			return "redirect:/admin/user"+getParams(pageable, filter);
		}


	
}
