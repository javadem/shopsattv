package ua.service.implementation;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import ua.entity.Product;
import ua.repository.MeasureRepository;
import ua.repository.ModelRepository;
import ua.repository.ProductRepository;
import ua.service.ProductService;
import ua.service.specification.ProductSpecification;
import ua.dto.filter.ProductFilter;
import ua.dto.form.ProductForm;




@Service
public class ProductServiceImpl implements ProductService{
	

	@Autowired
	private ProductRepository  productRepository;
	
	@Autowired
	private ModelRepository  modelRepository;
	
	@Autowired
	private MeasureRepository  measureRepository;
	
	

	public ProductServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	public ProductServiceImpl(ProductRepository productRepository, ModelRepository modelRepository,
			MeasureRepository measureRepository) {
		super();
		this.productRepository = productRepository;
		this.modelRepository = modelRepository;
		this.measureRepository = measureRepository;
	}



	public ProductRepository getProductRepository() {
		return productRepository;
	}

	public void setProductRepository(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	public ModelRepository getModelRepository() {
		return modelRepository;
	}

	public void setModelRepository(ModelRepository modelRepository) {
		this.modelRepository = modelRepository;
	}

	public MeasureRepository getMeasureRepository() {
		return measureRepository;
	}

	public void setMeasureRepository(MeasureRepository measureRepository) {
		this.measureRepository = measureRepository;
	}
	
	
	
// MUST RETURN ProductForm	
//	@Override
////	@Transactional(readOnly=true)
//	public Product findOne(int id) {
//		// TODO Auto-generated method stub
//		return productRepository.findOne(id);
//	}

	@Override
//	@Transactional(readOnly=true)
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

//	@Override
//	public void save(Product product) {
//		// TODO Auto-generated method stub
//		productRepository.save(product);
//	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		productRepository.delete(id);
	}

	@Override
	public Product findOne(String name) {
		return productRepository.findByName(name);
	}
	
	
	

//	@Override
//	public void update(Product product) {
//		// TODO Auto-generated method stub
////		productRepository.update(product);
//	}


////getForm
//	@Override
//	public void getForm(int id) {
//		// TODO Auto-generated method stub
////		productRepository.update(id);
//	}

	

	@Override
	@Transactional
	public void save(ProductForm productForm) {
		// TODO Auto-generated method stub
		Product product = new Product();
		product.setId(productForm.getId());
		product.setNameProduct(productForm.getNameProduct());
		product.setModel(productForm.getModel());
		product.setDescription(productForm.getDescription());
		product.setPrice(new BigDecimal(productForm.getPrice().replace(',', '.')));
		product.setMeasure(productForm.getMeasure());
		productRepository.save(product);
	}

	@Override
	public void update(int id) {
		// TODO Auto-generated method stub
		
	}

	

//	@Override
//	public Product getForm() {
//		// TODO Auto-generated method stub
//		return null;
//	}






	@Override
	public void update(ProductForm productForm) {
		// TODO Auto-generated method stub
		
	}


	
	

	@Override
	public ProductForm findOne(int id) {
		// TODO Auto-generated method stub
		return productRepository.findOne(id);
	}



	@Override
	public Page<Product> findAll(ProductFilter filter, Pageable pageable) {
		System.out.println("---------------------------------------------------------------");
		Page<Product> products = productRepository.findAll(new ProductSpecification(filter),pageable);
		System.out.println("---------------------------------------------------------------");
		return products;
	}
	
	
	
}
