package ua.editor;

import java.beans.PropertyEditorSupport;

import ua.service.ModelService;
import ua.service.UserService;

public class UserEditor   extends PropertyEditorSupport{

	private final UserService userService;



	public UserEditor(UserService userService) {
		super();
		this.userService = userService;
	}

	
	
	public UserService getUserService() {
		return userService;
	}



	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		ua.entity.User user = userService.findOne(Integer.valueOf(text));
		setValue(user);
	}

	
	
}
