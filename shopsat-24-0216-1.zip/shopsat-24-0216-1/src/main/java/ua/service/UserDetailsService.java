package ua.service;

import ua.entity.User;

public interface UserDetailsService {

	void loadUserByUsername(String username);
	
}
