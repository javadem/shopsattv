package ua.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

import javax.inject.Inject;
import javax.validation.Valid;


//import static ua.service.utils.ParamBuilder.getParams;

import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;

import ua.dto.filter.ProductFilter;
import ua.dto.form.ProductForm;
import ua.editor.MeasureEditor;
import ua.editor.ModelEditor;
import ua.entity.Measure;
import ua.service.MeasureService;
import ua.service.ModelService;
import ua.service.ProductService;
import ua.validator.ProductValidator;

@Controller
@RequestMapping("/admin/product")
@SessionAttributes(names="product")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private ModelService modelService;
	
	@Autowired
	private MeasureService measureService;
	

	@Inject
	public ProductController(ProductService productService, ModelService modelService, MeasureService measureService) {
		super();
		this.productService = productService;
		this.modelService = modelService;
		this.measureService = measureService;
	}

	@InitBinder("product")
	protected void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(ua.entity.Model.class, new ModelEditor(modelService));
		binder.registerCustomEditor(Measure.class, new MeasureEditor(measureService));
		binder.setValidator(new ProductValidator(productService));
//		binder.setValidator(new ProductValidator());
	}
	
	@ModelAttribute("product")
	public ProductForm getForm(){
		return new ProductForm();
	}
	
	@ModelAttribute("filter")
	public ProductFilter getFilter(){
		return new ProductFilter();
	}
	
	@RequestMapping
	public String show(Model model, @PageableDefault Pageable pageable, @ModelAttribute("filter") ProductFilter filter){	
//		model.addAttribute("products", productService.findAll());
		model.addAttribute("page", productService.findAll( filter, pageable));
		model.addAttribute("models", modelService.findAll());
		model.addAttribute("measures", measureService.findAll());
		return "admin-product";
	}
	
	@RequestMapping("/delete/{id}")
	public String delete(@PathVariable int id, @ModelAttribute("filter") ProductFilter filter, @PageableDefault Pageable pageable){
		productService.delete(id);
		return "redirect:/admin/product"+getParams(pageable, filter);
	}
	
	@RequestMapping("/add/{id}")
	public String showAdd(@PathVariable int id, Model model, @PageableDefault Pageable pageable, @ModelAttribute("filter") ProductFilter filter){
		model.addAttribute("measures", measureService.findAll());
		model.addAttribute("page", productService.findAll(filter, pageable));
		model.addAttribute("model", modelService.findOne(id));
		return "admin-product";
	}

	
	@RequestMapping(method=POST)
	public String save(@ModelAttribute("product") @Valid ProductForm product, BindingResult br, SessionStatus status, Model model, @ModelAttribute("filter") ProductFilter filter, @PageableDefault Pageable pageable){
		if(br.hasErrors()){
//			model.addAttribute("products", productService.findAll());
			model.addAttribute("page", productService.findAll( filter, pageable));
			model.addAttribute("models", modelService.findAll());
//			model.addAttribute("models", product.getModel());
			model.addAttribute("measures", measureService.findAll());
			return "admin-product";
		}
		productService.save(product);
		status.setComplete();
		return "redirect:/admin/product"+getParams(pageable, filter);
	}



	@RequestMapping("/update/{id}")
	public String update(@PathVariable int id, Model model, @PageableDefault Pageable pageable, @ModelAttribute("filter") ProductFilter filter){
//		model.addAttribute("products", productService.findAll());
		model.addAttribute("page", productService.findAll( filter, pageable));
		model.addAttribute("measures", measureService.findAll());
		model.addAttribute("models", modelService.findAll());
		return "admin-product";
	}
	
	private String getParams(Pageable pageable, ProductFilter filter){
		StringBuilder buffer = new StringBuilder();
		buffer.append("?page=");
		buffer.append(String.valueOf(pageable.getPageNumber()+1));
		buffer.append("&size=");
		buffer.append(String.valueOf(pageable.getPageSize()));
		if(pageable.getSort()!=null){
			buffer.append("&sort=");
			Sort sort = pageable.getSort();
			sort.forEach((order)->{
				buffer.append(order.getProperty());
				if(order.getDirection()!=Direction.ASC)
				buffer.append(",desc");
			});
		}
		if(!filter.getSearch().isEmpty()){
			buffer.append("&search=");
			buffer.append(filter.getSearch());
		}
	
		if(!filter.getMaxPrice().isEmpty()){
			buffer.append("&maxPrice=");
			buffer.append(filter.getMaxPrice());
		}
		if(!filter.getMinPrice().isEmpty()){
			buffer.append("&minPrice=");
			buffer.append(filter.getMinPrice());
		}
		for(Integer id : filter.getModelIds()){
			buffer.append("&modelIds=");
			buffer.append(id);
		}
		for(Integer id : filter.getMeasureIds()){
			buffer.append("&measureIds=");
			buffer.append(id);
		}

		
		if(!filter.getDescription().isEmpty()){
			buffer.append("&description=");
			buffer.append(filter.getDescription());
		}


		return buffer.toString();
	}
}
