package ua.dto.filter;

import java.util.ArrayList;
import java.util.List;

public class UserFilter {

	private String search = "";

	public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}
	
}
