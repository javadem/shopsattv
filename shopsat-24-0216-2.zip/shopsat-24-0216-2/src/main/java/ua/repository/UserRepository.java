package ua.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import ua.entity.Country;
import ua.entity.User;
import ua.service.specification.UserSpecification;

public interface UserRepository extends JpaRepository<User, Integer>{

	User findByUsername(String username);

	@Query(value="SELECT i FROM User i ")
	Page<User> findAll(UserSpecification userSpecification, Pageable pageable);
	


}
