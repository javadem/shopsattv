package ua.validator;

import java.util.regex.Pattern;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import ua.entity.Country;
import ua.entity.User;
import ua.service.ProductService;
import ua.service.UserService;

public class UserValidator   implements Validator{

	private final UserService userService;
	
//	private  ProductService productServiceProductValidator;

	private final static Pattern PATTERN = Pattern.compile("^([0-9][a-z][A-Z]{6,18}\\.[0-9]{0,2})|([0-9]{1,18}\\,[0-9]{0,2})$");
	
	
	
	public UserValidator(UserService userService) {
	super();
	this.userService = userService;
}

	public UserService getUserService() {
		return userService;
	}

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return User.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		User user = (User)target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "", "Can`t be empty");
		if(userService.findOne(user.getUsername())!=null){
			errors.rejectValue("username", "", "Already exist");
		}
		if(!PATTERN.matcher(user.getUsername()).matches()){
			errors.rejectValue("username", "", "Wrong format, only litera and digits after separator");
		}
	}

}
