package ua.controller.admin;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import ua.dto.filter.UserFilter;
import ua.dto.form.UserForm;
import ua.entity.User;
//import ua.entity.User;
import ua.service.UserService;
import ua.validator.UserValidator;

@Controller
@RequestMapping("/admin/user")
@SessionAttributes(names="userForm")
public class UserFormController {

/*	@Autowired
	private UserService userService ;
	

	
	@ModelAttribute("userForm")
	public UserForm getForm(){
		return new UserForm();
	}
	

	
	@InitBinder("userForm")
	protected void initBinder(WebDataBinder binder) {
//		binder.registerCustomEditor(User.class, new UserEditor(userService));
		binder.setValidator(new UserValidator(userService));
	}
	
	@RequestMapping
//	public String show(Model model){
	public String show(Model model, @PageableDefault Pageable pageable){	
//	public String show(Model model, @ModelAttribute("filter") UserFilter filter, @PageableDefault Pageable pageable){
//		model.addAttribute("users", userService.findAll());
		model.addAttribute("page", userService.findAll( pageable));
//		model.addAttribute("page", userService.findAll( filter, pageable));
		return "admin-user";
	}
	

	
	
	@RequestMapping(method=POST)
//	public String save(@ModelAttribute("user") @Valid User user, BindingResult br, SessionStatus status, Model model){
	public String save(@ModelAttribute("userForm") @Valid UserForm user, BindingResult br, SessionStatus status, Model model,  @PageableDefault Pageable pageable){	
//	public String save(@ModelAttribute("user") @Valid User user, BindingResult br, SessionStatus status, Model model, @ModelAttribute("filter") UserFilter filter, @PageableDefault Pageable pageable){
		if(br.hasErrors()){
//			model.addAttribute("users", userService.findAll());
			model.addAttribute("page", userService.findAll( pageable));
//			model.addAttribute("page", userService.findAll( filter, pageable));
			return "admin-user";
		}
		userService.save(user);
		status.setComplete();
//		return "redirect:/admin/user"+getParams(pageable, filter);
		return "redirect:/admin/user"+getParams(pageable);
//		return "redirect:/admin/user";
	}

	
	

	
	
public static String getParams(Pageable pageable){
		
		StringBuilder buffer = new StringBuilder();
		buffer.append("?page=");
		buffer.append(String.valueOf(pageable.getPageNumber()+1));
		buffer.append("&size=");
		buffer.append(String.valueOf(pageable.getPageSize()));
		if(pageable.getSort()!=null){
			buffer.append("&sort=");
			Sort sort = pageable.getSort();
			sort.forEach((order)->{
				buffer.append(order.getProperty());
				if(order.getDirection()!=Direction.ASC)
				buffer.append(",desc");
			});
		}
		
		return buffer.toString();
	}

*/
	
}
