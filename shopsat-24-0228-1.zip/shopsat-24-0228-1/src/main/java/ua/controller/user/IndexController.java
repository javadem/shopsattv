package ua.controller.user;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.security.Principal;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import ua.entity.User;
import ua.service.UserService;
import ua.validator.UserValidator;

@Controller
//@RequestMapping("/user/registration")
@SessionAttributes(names="userForm")
public class IndexController {
	
	@Autowired
	private UserService userService;
	
	@ModelAttribute("userForm")
	public User getForm(){
		return new User();
	}
	
	@InitBinder("userForm")
	protected void initBinder(WebDataBinder binder) {
		binder.setValidator(new UserValidator(userService));
	}

	@RequestMapping("/")
	public String index(Principal principal){
		if(principal!=null)
		System.out.println(principal.getName());
		return "user-index";
	}
	
	@RequestMapping("/admin")
	public String admin(){
		return "admin-admin";
	}
	
	@RequestMapping("/login")
	public String login(){
		return "user-login";
	}
	
	@RequestMapping("/registration")
	public String registration(Model model){
		model.addAttribute("userForm", new User());
		
		return "user-registration";
	}
	
	
	@RequestMapping(value="/registration", method=POST)
	public String registration(@ModelAttribute("userForm") @Valid  User user, Model model, BindingResult bindingResult){
		if(bindingResult.hasErrors()){
//			model.addAttribute("registration", userService.findAll());
			return "user-registration";
		}

		//		UserValidator userValidator = new UserValidator(userService);
//		Errors errors = null;
//		userValidator.validate(user, errors );
//		if(user.getUsername().isEmpty()){
//			System.out.println("Username EMPTY");
//			return "user-registration";}
//		user.setEmail(user.getEmail());
//		user.setUsername(user.getUsername());
//		user.setPassword(user.getPassword());
		userService.save(user);
		return "redirect:/login";
	}
}