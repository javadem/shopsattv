package ua.dto.form;

import java.util.ArrayList;
import java.util.List;


import ua.entity.Product;
import ua.entity.Role;

public class UserForm {
	

	private int id;
	
	private String username;
	
	
	private String password;
	
	
	private String email;
	

	private Role role;
	
	private List<Product> products = new ArrayList<>();


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Role getRole() {
		return role;
	}


	public void setRole(Role role) {
		this.role = role;
	}


	public UserForm() {
		super();
		// TODO Auto-generated constructor stub
	}


	public List<Product> getProducts() {
		return products;
	}


	public void setProducts(List<Product> products) {
		this.products = products;
	}
	
	
	

}
