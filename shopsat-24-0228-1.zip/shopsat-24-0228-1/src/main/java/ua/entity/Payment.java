package ua.entity;

public class Payment {

}
