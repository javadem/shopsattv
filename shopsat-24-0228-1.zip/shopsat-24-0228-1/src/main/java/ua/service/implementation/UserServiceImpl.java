package ua.service.implementation;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ua.dto.filter.UserFilter;
import ua.dto.form.UserForm;
import ua.entity.Role;
import ua.entity.User;
import ua.repository.ProductRepository;
import ua.repository.UserRepository;
import ua.service.UserService;
import ua.service.specification.UserSpecification;
import ua.validator.UserValidator;

@Repository
@Transactional
@Service("userDetailsService")
public class UserServiceImpl implements UserDetailsService, UserService{

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private BCryptPasswordEncoder encoder;
	
	@Override
	public UserDetails loadUserByUsername(String username)
			throws UsernameNotFoundException {
		return userRepository.findByUsername(username);
	}

//	@Override
//	public void save(User user) {
//		user.setEmail(user.getEmail());
//		user.setUsername(user.getUsername());
//		user.setPassword(encoder.encode(user.getPassword()));
//		user.setRole(Role.ROLE_USER);
//		userRepository.save(user);
//	}
	
	
	
	
	@Override
	public void save(UserForm userForm) {
		User user = new User();
		user.setEmail(userForm.getEmail());
		user.setId(userForm.getId());
		user.setUsername(userForm.getUsername());
		user.setPassword(encoder.encode(userForm.getPassword()));
		user.setRole(Role.ROLE_USER);
		userRepository.save(user);
	}
	
	@Override
	public User save(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}

	@PostConstruct
	public void admin(){
		User user = userRepository.findByUsername("admin");
		if(user==null){
			user = new User();
			user.setEmail("admin");
			user.setPassword(encoder.encode("admin"));
			user.setRole(Role.ROLE_ADMIN);
			user.setUsername("admin");
			userRepository.save(user);
		}
	}

	
	
	@Override
	@Transactional(readOnly=true)
	public User findOne(int id) {
		// TODO Auto-generated method stub
		return userRepository.findOne(id);
	}

	@Override
	@Transactional(readOnly=true)
	public User findOne(String name) {
		// TODO Auto-generated method stub
		return userRepository.findByUsername(name);
	}

	@Override
	@Transactional(readOnly=true)
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	@Transactional(readOnly=true)
	public Page<User> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return userRepository.findAll( pageable);
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		userRepository.delete(id);
	}

	public UserRepository getUserRepository() {
		return userRepository;
	}

	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	public ProductRepository getProductRepository() {
		return productRepository;
	}

	public void setProductRepository(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	public BCryptPasswordEncoder getEncoder() {
		return encoder;
	}

	public void setEncoder(BCryptPasswordEncoder encoder) {
		this.encoder = encoder;
	}

	

//	@Override
//	public Page<User> findAll(UserFilter filter, Pageable pageable) {
//		// TODO Auto-generated method stub
//		return userRepository.findAll(new UserSpecification(filter), pageable);
//	}

//	@Override
//	public Page<User> findAll(UserFilter filter, Pageable pageable) {
//		// TODO Auto-generated method stub
//		return userRepository.findAll(new UserSpecification(filter), pageable);
//	}
	
	
	
}