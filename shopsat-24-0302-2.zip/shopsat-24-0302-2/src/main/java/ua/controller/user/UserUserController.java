package ua.controller.user;

import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMethod;

import ua.entity.User;
import ua.service.UserService;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/users")
@Controller
public class UserUserController {

	private UserService userService;
	
	@RequestMapping(method = RequestMethod.GET)
	public String list(Model uiModel) {
	List<User> users = userService.findAll();
	uiModel. addAttribute ( "users", users);
	return "users/list";
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	
	
	
}
