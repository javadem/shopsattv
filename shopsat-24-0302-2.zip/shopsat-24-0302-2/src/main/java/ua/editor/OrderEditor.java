package ua.editor;

import java.beans.PropertyEditorSupport;

import ua.entity.Order;
import ua.service.OrderService;

public class OrderEditor extends PropertyEditorSupport {

	private final OrderService orderService;

	

	public OrderEditor(OrderService orderService) {
		super();
		this.orderService = orderService;
	}



	public OrderService getOrderService() {
		return orderService;
	}



	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		Order order = orderService.findOne(Integer.valueOf(text));
		setValue(order);
	}


}
