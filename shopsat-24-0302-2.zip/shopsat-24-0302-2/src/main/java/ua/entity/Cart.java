package ua.entity;

//import javax.persistence.Entity;
//import javax.persistence.Table;
//
//@Entity
//@Table(name="cart"/*, indexes=@Index(columnList = "_name")*/)
public class Cart extends AbstractClass{

}
