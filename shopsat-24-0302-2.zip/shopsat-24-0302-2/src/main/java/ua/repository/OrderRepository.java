package ua.repository;

public class OrderRepository {

}
