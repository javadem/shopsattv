package ua.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import ua.dto.filter.ModelFilter;
import ua.dto.filter.OrderFilter;
import ua.entity.Order;

public interface OrderService {

	Order findOne(int id);
	
	List<Order> findAll();
	
//	void save( ua.entity.Model model);
	void save( Order order);
	
	void delete(int id);
	
	Order findOne(String name);
	
	List<Order> findByUserId(int id);
	
//	List<Order> findByProducerId(int id);
	
	Page<Order> findAll(Pageable pageable);
//
//	Page<Model> findAll(BasicFilter filter, Pageable pageable);
	
//	Page<Order> findAll(OrderFilter filter, Pageable pageable);
	
}
