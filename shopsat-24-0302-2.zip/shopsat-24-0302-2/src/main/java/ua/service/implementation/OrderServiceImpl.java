package ua.service.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import ua.entity.Order;
import ua.repository.ModelRepository;
import ua.repository.OrderRepository;
import ua.service.OrderService;

public class OrderServiceImpl implements OrderService{
	
	@Autowired
	private OrderRepository  orderRepository;

	@Override
	public Order findOne(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Order> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Order order) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Order findOne(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Order> findByUserId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page<Order> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
