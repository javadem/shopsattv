package ua.service.implementation;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import ua.entity.Product;
import ua.repository.MeasureRepository;
import ua.repository.ModelRepository;
import ua.repository.ProductRepository;
import ua.repository.UserRepository;
import ua.service.FileWriter;
import ua.service.FileWriter.Folder;
import ua.service.ProductService;
import ua.service.specification.ProductSpecification;
import ua.dto.filter.ProductFilter;
import ua.dto.form.ProductForm;




@Service
public class ProductServiceImpl implements ProductService{
	

	@Autowired
	private ProductRepository  productRepository;
	
	@Autowired
	private ModelRepository  modelRepository;
	
	@Autowired
	private MeasureRepository  measureRepository;
	
	@Autowired
	private FileWriter fileWriter;
	
	@Autowired
	private UserRepository  userRepository;
	

	public ProductServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductServiceImpl(ProductRepository productRepository, ModelRepository modelRepository,
			MeasureRepository measureRepository, FileWriter fileWriter) {
		super();
		this.productRepository = productRepository;
		this.modelRepository = modelRepository;
		this.measureRepository = measureRepository;
		this.fileWriter = fileWriter;
	}


	public ProductRepository getProductRepository() {
		return productRepository;
	}

	public void setProductRepository(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	public ModelRepository getModelRepository() {
		return modelRepository;
	}

	public void setModelRepository(ModelRepository modelRepository) {
		this.modelRepository = modelRepository;
	}

	public MeasureRepository getMeasureRepository() {
		return measureRepository;
	}

	public void setMeasureRepository(MeasureRepository measureRepository) {
		this.measureRepository = measureRepository;
	}
	
	public FileWriter getFileWriter() {
		return fileWriter;
	}

	public void setFileWriter(FileWriter fileWriter) {
		this.fileWriter = fileWriter;
	}
	
// MUST RETURN ProductForm	
	@Override
////	@Transactional(readOnly=true)
	public ProductForm findOne(int id) {
//		// TODO Auto-generated method stub
		return productRepository.findOne(id);
	}

	@Override
//	@Transactional(readOnly=true)
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}


	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		productRepository.delete(id);
	}

	@Override
	public Product findOne(String name) {
		return productRepository.findByName(name);
	}

//	@Override
//	public void update(Product product) {
//		// TODO Auto-generated method stub
////		productRepository.update(product);
//	}


////getForm
//	@Override
//	public void getForm(int id) {
//		// TODO Auto-generated method stub
////		productRepository.update(id);
//	}
	
	/*private void saveImage(String filename, MultipartFile image)
//			throws ImageUploadException
	{
		File pathToHome = new File(System.getProperty("catalina.home"));
//		File pathToFolder = new File(pathToHome, "images" + File.separator + folder.name().toLowerCase());
			try {
			File file = new File(pathToHome + "/images/" + filename);
			FileUtils.writeByteArrayToFile(file, image.getBytes());
			} catch (IOException e) {
//			throw new ImageUploadException("Unable to save image", e);
			}
			}*/

	@Override
	@Transactional
	public void save(ProductForm productForm) {
		
		Product product = new Product();
		product.setId(productForm.getId());
		product.setNameProduct(productForm.getNameProduct());
		product.setModel(productForm.getModel());
		product.setDescription(productForm.getDescription());
		product.setPrice(new BigDecimal(productForm.getPrice().replace(',', '.')));
		product.setMeasure(productForm.getMeasure());
//		product.se
		product.setUsers(productForm.getUsers());
	
		productRepository.saveAndFlush(product);
		
		if(fileWriter.write(Folder.ITEM, productForm.getFile(), product.getId())){
//			
			if(product.getVersion()==null)product.setVersion(0);
			else product.setVersion(product.getVersion()+1);
		}
//		productRepository.saveAndFlush(product);
//		productRepository.save(product);
	}
	
	

	@Override
	public void save(ProductForm productForm, MultipartFile image) {
		// TODO Auto-generated method stub
		
	}



	@Override
	@Transactional
	public void update(int id) {
		// TODO Auto-generated method stub
		ProductForm productForm = productRepository.findOne(id);
		
		productForm.setId(productForm.getId());
		productForm.setNameProduct(productForm.getNameProduct());
		productForm.setModel(productForm.getModel());
		productForm.setDescription(productForm.getDescription());
//		productForm.setPrice(new BigDecimal(productForm.getPrice().replace(',', '.')));
		productForm.setMeasure(productForm.getMeasure());
//		productForm.setUsers(productForm.getUsers());
//		productRepository.save(productForm);
	}

	
	
//	@Override
//	public Product getForm() {
//		// TODO Auto-generated method stub
//		return null;
//	}

	public UserRepository getUserRepository() {
		return userRepository;
	}

	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Override
	public void update(ProductForm productForm) {
		// TODO Auto-generated method stub
		
	}

//	@Override
//	public ProductForm findOne(int id) {
//		// TODO Auto-generated method stub
//		return productRepository.findOne(id);
//	}



//	@Override
//	public Page<Product> findAll(Pageable pageable) {
//		// TODO Auto-generated method stub
//		return productRepository.findAll(pageable);
//	}

	@Override
	public Page<Product> findAll(ProductFilter filter, Pageable pageable) {
		Page<Product> products = productRepository.findAll(new ProductSpecification(filter),pageable);
		return products;
	}

	
}
