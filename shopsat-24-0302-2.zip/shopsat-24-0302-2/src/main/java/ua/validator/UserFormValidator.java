package ua.validator;

import java.util.regex.Pattern;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import ua.dto.form.UserForm;
import ua.service.UserService;

public class UserFormValidator   implements Validator{

	private final UserService userService;

	private final static Pattern PATTERN = Pattern.compile("^[0-9][a-z][A-Z]{4,16}+$");
	
	


	public UserFormValidator(UserService userService) {
		super();
		this.userService = userService;
	}

	public UserService getUserService() {
		return userService;
	}

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return UserForm.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		UserForm userForm = (UserForm)target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "", "Can`t be empty");
		if(userService.findOne(userForm.getUsername())!=null){
			errors.rejectValue("username", "", "Already exist");
		}
		if(PATTERN.matcher(userForm.getUsername()).matches()){
			errors.rejectValue("username", "", "Wrong format, only letters and digits");
		}
		
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "", "Can`t be empty");
		if(PATTERN.matcher(userForm.getPassword()).matches()){
			errors.rejectValue("password", "", "Wrong format, only letters and digits");
		}
		
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "", "Can`t be empty");
		if(userService.findOne(userForm.getEmail())!=null){
			errors.rejectValue("email", "", "Already exist");
		}
		if(PATTERN.matcher(userForm.getEmail()).matches()){
			errors.rejectValue("email", "", "Wrong format, only letters and digits");
		}
	}

	
}
