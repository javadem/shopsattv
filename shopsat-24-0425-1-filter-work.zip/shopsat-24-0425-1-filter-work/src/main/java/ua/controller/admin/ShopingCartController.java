package ua.controller.admin;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import ua.dto.filter.ShopingCartFilter;
import ua.dto.filter.UserFilter;
import ua.dto.form.ProductForm;
import ua.editor.MeasureEditor;
import ua.editor.ModelEditor;
import ua.editor.ProductEditor;
import ua.editor.ShopingCartEditor;
import ua.editor.UserEditor;
import ua.entity.Measure;
import ua.entity.Product;
import ua.entity.ShopingCart;
import ua.entity.User;
import ua.service.MeasureService;
import ua.service.ModelService;
import ua.service.ProductService;
import ua.service.ShopingCartService;
import ua.service.UserService;
import ua.validator.ProductValidator;

@Controller
@RequestMapping(value="/admin/shopingCart")
@SessionAttributes(names="shopingCart")
public class ShopingCartController {
	
	@Autowired
	private ShopingCartService shopingCartService ;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private UserService userService;
	
	@InitBinder("shopingCart")
	protected void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(ShopingCart.class, new ShopingCartEditor(shopingCartService));
		binder.registerCustomEditor(Product.class, new ProductEditor(productService));
		binder.registerCustomEditor(User.class, new UserEditor(userService));
	}

	@ModelAttribute("shopingCart")
	public ShopingCart getForm(){
		return new ShopingCart();
	}
	
	@ModelAttribute("filter")
	public ShopingCartFilter getFilter(){
		return new ShopingCartFilter();
	}
	

	@RequestMapping
	public String show(Model model){
		model.addAttribute("products", productService.findAll());
		model.addAttribute("shopingCarts", shopingCartService.findAll());
		model.addAttribute("users", userService.findAll());
		return "admin-shopingCart";
	}
	
	@RequestMapping("/delete/{id}")
	public String delete(@PathVariable int id){

		shopingCartService.delete(id);
	return "redirect:/admin/shopingCart";

}
	


	@RequestMapping(method=POST)
	public String save(@ModelAttribute("shopingCart") ShopingCart shopingCart,  SessionStatus status, Model model){
	
				model.addAttribute("products", productService.findAll());
			model.addAttribute("shopingCarts", shopingCartService.findAll());
			model.addAttribute("users", userService.findAll());
		System.out.println("111111111111111");
		shopingCartService.save(shopingCart);
		System.out.println("222222222222");
		status.setComplete();
		System.out.println("3333333333333333");
		return "redirect:/admin/shopingCart";
		
	}

/*	@RequestMapping(method=POST)
	public String save(@RequestParam User user, @RequestParam Product product){
		shopingCartService.save(user, product);
		return "redirect:/admin/shopingCart";
	}*/
	
	
	@RequestMapping("/update/{id}")
	public String update(@PathVariable int id, Model model){
		model.addAttribute("shopingCart", shopingCartService.findOne(id));
		model.addAttribute("users", userService.findAll());
		model.addAttribute("products", productService.findAll());
		return "admin-shopingCart";
	}
	
/*	@Autowired
	private ShopingCartService shopingCartService ;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private UserService userService;

	@InitBinder("shopingCart")
	protected void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(ShopingCart.class, new ShopingCartEditor(shopingCartService));
		binder.registerCustomEditor(Product.class, new ProductEditor(productService));
		binder.registerCustomEditor(User.class, new UserEditor(userService));
	}
	
	@ModelAttribute("shopingCart")
	public ShopingCart getForm(){
		return new ShopingCart();
	}
	
	@ModelAttribute("filter")
	public ShopingCartFilter getFilter(){
		return new ShopingCartFilter();
	}
	
	@RequestMapping(value="/{id}", method=RequestMethod.POST)
	public ShopingCart findCartById(@PathVariable int id){
		return shopingCartService.findOne(id);
	}
	
	@RequestMapping(value="/", method=RequestMethod.POST)
	public ShopingCart create(ShopingCart shopingCart){
		shopingCartService.save(shopingCart);
		return shopingCart;
	}
	
	
	@RequestMapping
	public String show(Model model){
		model.addAttribute("products", productService.findAll());
		model.addAttribute("shopingCarts", shopingCartService.findAll());
		model.addAttribute("users", userService.findAll());
		return "admin-shopingCart";
	}
	
	@RequestMapping(method=POST)
	public String save(@ModelAttribute("shopingCart") ShopingCart shopingCart,  SessionStatus status){
	
//			model.addAttribute("products", productService.findAll());
//			model.addAttribute("shopingCarts", shopingCartService.findAll());
//			model.addAttribute("users", userService.findAll());
		System.out.println("111111111111111");
		shopingCartService.save(shopingCart);
		System.out.println("222222222222");
		status.setComplete();
		System.out.println("3333333333333333");
		return "redirect:/admin/shopingCart";
		
	}
	
	@RequestMapping("/delete/{id}")
	public String delete(@PathVariable int id){

		userService.delete(id);
	return "redirect:/admin/shopingCart";

}
//	
	@RequestMapping("/update/{id}")
	public String update(@PathVariable int id, Model model){
		model.addAttribute("users", userService.findAll());
		model.addAttribute("products", productService.findAll());
		return "admin-shopingCart";
	}
	
	
	

	*/
	

}
