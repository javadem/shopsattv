package ua.controller.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ua.entity.Product;
import ua.service.MeasureService;
import ua.service.ModelService;
import ua.service.ProductService;
import ua.service.UserService;


@RestController
@RequestMapping("/product")
public class RestProductController {
	
//	@Autowired
	private ProductService productService;
	
//	@Autowired
	private ModelService modelService;
	
//	@Autowired
	private MeasureService measureService;
	
//	@Autowired
	private UserService userService;
	
	

	public RestProductController() {
	}

	

	public RestProductController(ProductService productService) {
		super();
		this.productService = productService;
	}



	public RestProductController(ProductService productService,
		ModelService modelService, MeasureService measureService,
		UserService userService) {
	super();
	this.productService = productService;
	this.modelService = modelService;
	this.measureService = measureService;
	this.userService = userService;
	}


	public ProductService getProductService() {
		return productService;
	}
	
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}
	
	public ModelService getModelService() {
		return modelService;
	}
	
	public void setModelService(ModelService modelService) {
		this.modelService = modelService;
	}
	
	public MeasureService getMeasureService() {
		return measureService;
	}
	
	public void setMeasureService(MeasureService measureService) {
		this.measureService = measureService;
	}
	
	public UserService getUserService() {
		return userService;
	}
	
	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	
/*	@RequestMapping(value="/{id}", method=RequestMethod.GET)
	public String getProduct(@PathVariable("id") int id, Model model) {
		model.addAttribute(productService.findOne(id));
//			model.addAttribute(productService.getSpittleById(id));
		return "product/view";
		}*/
	
	@RequestMapping(value="*/{id}", method=RequestMethod.GET)
	public @ResponseBody
	Product showProduct(@PathVariable int id) {

		return productService.findById(id);
		}
	
/*	@RequestMapping(value="/{id}", method=RequestMethod.GET)
	public Model getProduct(@PathVariable int id) {
		Product product = productService.findById(id);
		
		
	}*/

}
