package ua.dto;

public class Quantity {

	private int count;
	
	public Quantity(int count) {
		this.count = count;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
}
