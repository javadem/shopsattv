package ua.dto.filter;

public class OrderFilter {

}
