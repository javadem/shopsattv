package ua.editor;

import java.beans.PropertyEditorSupport;

import ua.entity.*;
import ua.service.*;


public class CartEditor  extends PropertyEditorSupport{

	private final CartService cartService;

	public CartEditor(CartService cartService) {
		super();
		this.cartService = cartService;
	}

	public CartService getCartService() {
		return cartService;
	}

	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		Cart cart = cartService.findOne(Integer.valueOf(text));
		setValue(cart);
	}

	
}
