package ua.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="cart"/*, indexes=@Index(columnList = "_name")*/)
public class Cart extends AbstractClass{

	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="id_user")
	private User user;
	
	
	@ManyToMany
//	(mappedBy = "shopingCart")
	private List<Product> products = new ArrayList<>();
	
	
	@Column(name="_count")
	private int count;
	
	
	
/*	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="id_product")
	private Product product;*/

	public Cart() {
		
	}



	public Cart(User user, List<Product> products, int count) {
		super();
		this.user = user;
		this.products = products;
		this.count = count;
	}



	public void add(Product product) {
		products.add(product);
		count = products.size();
	}



	public User getUser() {
		return user;
	}



	public void setUser(User user) {
		this.user = user;
	}



	public List<Product> getProducts() {
		return products;
	}



	public void setProducts(List<Product> products) {
		this.products = products;
	}



	public int getCount() {
		return count;
	}



	public void setCount(int count) {
		this.count = count;
	}


	

	
}
