package ua.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="shopingCart"/*, indexes=@Index(columnList = "_name")*/)
public class ShopingCart extends AbstractClass{

	
	
	@OneToMany(mappedBy="shopingCart")
	private List<User> users = new ArrayList<>();
	
	
	@ManyToMany
//	(mappedBy = "shopingCart")
	private List<Product> products = new ArrayList<>();
	
	@Column(name="_count")
	private int count;
	
	/*	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="id_user")
	private User user;*/
	
/*	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="id_product")
	private Product product;*/

	public ShopingCart() {
		
	}


	public ShopingCart(List<User> users, List<Product> products, int count) {
		super();
		this.users = users;
		this.products = products;
		this.count = count;
	}

	public ShopingCart(List<User> users, List<Product> products) {
		super();
		this.users = users;
		this.products = products;
	}


	public void add(Product product) {
		products.add(product);
		count = products.size();
	}


	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}



	public List<Product> getProducts() {
		return products;
	}



	public void setProducts(List<Product> products) {
		this.products = products;
	}



	public List<User> getUsers() {
		return users;
	}



	public void setUsers(List<User> users) {
		this.users = users;
	}


	
}
