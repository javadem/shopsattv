package ua.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ua.entity.Cart;
import ua.entity.Model;
import ua.entity.Product;
import ua.entity.ShopingCart;

public interface CartRepository extends JpaRepository<Cart, Integer>{
	
//	@Query("SELECT DISTINCT i FROM Product i "
////			+ "LEFT JOIN FETCH i.model "
////			+ "LEFT JOIN FETCH i.measure "
//			+ " WHERE i.id=:id"
//			)
//	Product findOne(@Param("id")int id);
	
	
	@Query("SELECT i FROM Cart i "
			+ "LEFT JOIN FETCH i.products "
			+ "LEFT JOIN FETCH i.user"
			)
	List<Cart> findAll();
	
//	@Query("SELECT DISTINCT i FROM ShopingCart i LEFT JOIN FETCH i.product LEFT JOIN FETCH i.user WHERE i.id=:id")
//	ShopingCart findOne(@Param("id")int id);
	
/*	@Query("SELECT DISTINCT i FROM ShopingCart i  WHERE i.id=:id" )
	ShopingCart findOne(@Param("id")int id);
	
	@Query("SELECT  i FROM ShopingCart i  " )
	List<ShopingCart> findAll();*/
	
	@Query("SELECT DISTINCT i FROM Cart i "
			+ "LEFT JOIN FETCH i.products "
			+ "LEFT JOIN FETCH i.user"
		+ " WHERE i.id=:id"
		)
	Cart findOne(@Param("id")int id);
	
	
	
	
	
	
	
}
