
package ua.service;

import java.util.List;

import ua.entity.Cart;
import ua.entity.Producer;
import ua.entity.Product;
import ua.entity.ShopingCart;
import ua.entity.User;

public interface CartService {
	
	Cart findOne(int id);
	
	void save(Cart cart);
	
	void delete(int id);
	
	List<Cart> findAll();
	
	void addToCart(int userId, int prodId);

//	void save(User user, Product product);

}
