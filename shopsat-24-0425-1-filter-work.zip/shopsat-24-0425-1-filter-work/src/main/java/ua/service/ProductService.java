package ua.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import ua.dto.form.ProductForm;
import ua.entity.Product;
import ua.dto.filter.ProductFilter;

public interface ProductService {

//	Product findOne(int id);
	
	List<Product> findAll();
	
//	void save(Product product);
	
//	void update(Product product);
	
	void delete(int id);
	
	Product findOne(String name);
	
	Product findById(int id);
	
//	Product findOne(int id);
	
	ProductForm findOne(int id);
	
	void save(ProductForm productForm);
	
	
	
//	void update(ProductForm productForm);
	
//	void update(int id);
	
//	List<Product> findByModelId(int id);
	
//	List<Product> findByMeasureId(int id);

//	void getForm(int id);
	
//	Product getForm(int id);
	
//	Product getForm();
	
//	Page<Product> findAll(Pageable pageable);

	
	Page<Product> findAll(ProductFilter filter, Pageable pageable);

//	int findCount(int id);

	List<Product> findByUserId(int userId);
	
//	void save(ProductForm productForm, MultipartFile image);

//	List<Product> addProductToOrder(ProductForm productForm);

//	List<Product> addToOrder(Product product);

	List<Product> addToOrder(int id);

//	void update(int id);

	

	
}
