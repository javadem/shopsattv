package ua.service.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ua.entity.Cart;
import ua.repository.CartRepository;
import ua.repository.ProductRepository;
import ua.repository.ShopingCartRepository;
import ua.repository.UserRepository;
import ua.service.CartService;

@Service
public class CartServiceImpl implements CartService{
	
	@Autowired
	private ProductRepository  productRepository;
	
	@Autowired
	private CartRepository  cartRepository;
	
	@Autowired
	private UserRepository  userRepository;

	public CartServiceImpl() {
		
	}

	public CartServiceImpl(ProductRepository productRepository,
			CartRepository cartRepository, UserRepository userRepository) {
		super();
		this.productRepository = productRepository;
		this.cartRepository = cartRepository;
		this.userRepository = userRepository;
	}

	public ProductRepository getProductRepository() {
		return productRepository;
	}

	public void setProductRepository(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	public CartRepository getCartRepository() {
		return cartRepository;
	}

	public void setCartRepository(CartRepository cartRepository) {
		this.cartRepository = cartRepository;
	}

	public UserRepository getUserRepository() {
		return userRepository;
	}

	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Override
	public Cart findOne(int id) {
		// TODO Auto-generated method stub
		return cartRepository.findOne(id);
	}

	@Override
	public void save(Cart cart) {
		// TODO Auto-generated method stub
		cartRepository.save(cart);
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		cartRepository.delete(id);
	}

	@Override
	public List<Cart> findAll() {
		// TODO Auto-generated method stub
		return cartRepository.findAll();
	}

	@Override
	public void addToCart(int userId, int prodId) {
		// TODO Auto-generated method stub
		
	}
	
	

}
