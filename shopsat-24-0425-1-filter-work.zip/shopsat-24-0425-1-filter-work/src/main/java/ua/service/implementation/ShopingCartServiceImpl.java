package ua.service.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ua.entity.Product;
import ua.entity.ShopingCart;
import ua.entity.User;
import ua.repository.MeasureRepository;
import ua.repository.ModelRepository;
import ua.repository.ProductRepository;
import ua.repository.ShopingCartRepository;
import ua.repository.UserRepository;
import ua.service.FileWriter;
import ua.service.ShopingCartService;

@Service
public class ShopingCartServiceImpl implements ShopingCartService{
	
	@Autowired
	private ProductRepository  productRepository;
	
	@Autowired
	private ShopingCartRepository  shopingCartRepository;
	
	@Autowired
	private UserRepository  userRepository;
	

	public ProductRepository getProductRepository() {
		return productRepository;
	}

	public void setProductRepository(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	public ShopingCartRepository getShopingCartRepository() {
		return shopingCartRepository;
	}

	public void setShopingCartRepository(ShopingCartRepository shopingCartRepository) {
		this.shopingCartRepository = shopingCartRepository;
	}

	public UserRepository getUserRepository() {
		return userRepository;
	}

	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Override
	public ShopingCart findOne(int id) {
		// TODO Auto-generated method stub
		return shopingCartRepository.findOne(id);
	}

	@Override
	public void save(ShopingCart shoppingCart) {
		// TODO Auto-generated method stub
		shopingCartRepository.save(shoppingCart);
		
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ShopingCart> findAll() {
		// TODO Auto-generated method stub
		return shopingCartRepository.findAll();
	}
	
	@Override
	@Transactional
	public void addToShoppingCart(int userId, int productId) {
		
/*		User user = userRepository.findOne(userId);

		ShopingCart cart = new ShopingCart();
		
		ShopingCart cart = user.getShopingCarts().
		if(cart==null){
			cart = shopingCartRepository.save(new ShopingCart());
//			user.setShopingCarts(shopingCarts);
//			user.setShopingCart(cart);
		}
		Product product = productRepository.findOne(productId);
//		cart.add(product);
*/		
	}


	
	
	

}
